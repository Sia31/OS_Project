#!/bin/bash

#background
black="\e[40m"
red="\e[41m"
green="\e[42m"
bg_yellow="\e[43m"
yellow="\e[33;7m"
blue="\e[44m"
purple="\e[45m"
cyan="\e[46m"
white="\e[47m"



normal="\e[0m"

invisible="\e[8m"
reverse="\e[7m"
blink="\e[5m"
bold="\e[1m"
lowintensity="\e[2m"
underline="\e[4m"



#regular text color
rg_black="\e[30m"
rg_red="\e[31m"
rg_green="\e[32m"
rg_yellow="\e[33m"
rg_blue="\e[34m"
rg_purple="\e[35m"
rg_cyan="\e[36m"
rg_white="\e[37m"
