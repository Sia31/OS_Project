clear
bash index_page.sh
